 var express = require("express");
 var app = express();
 var cmServer = require("./Server/colourMemoryServer.js");
 var bodyParser = require('body-parser');

 app.use(bodyParser.json()); // for parsing application/json

 /* serves main page */
 app.get("/", function(req, res) {
    res.sendfile('mainView.html')
 });

 /* serves all the static files */
 app.get("/Scripts/\*", function(req, res){ 
     console.log('static file request : ' + req.path);
     res.sendFile( __dirname +  req.path); 
 });
 app.get("/Styles/\*", function(req, res){ 
     console.log('static file request : ' + req.path);
     res.sendFile( __dirname  + req.path); 
 });
 app.get("/Images/\*", function(req, res){ 
     console.log('static file request : ' + req.path);
     res.sendFile( __dirname + req.path); 
 });
 app.get("/Sounds/\*", function(req, res){ 
     console.log('static file request : ' + req.path);
     res.sendFile( __dirname + req.path); 
 });

 //Post Request
 app.post("/gamesave", function(req, res){ 
     function callback(resJson, resStatus){
     	console.log(resStatus);
     	res.status(resStatus).send(JSON.stringify(resJson));
     };
	//call the program that will connect with the DB for further processing
     cmServer.serve(req.body, callback); 
 });

//default port to listen
 var port = 80;
 
 app.listen(port, function() {
   console.log("Listening on " + port);
 });