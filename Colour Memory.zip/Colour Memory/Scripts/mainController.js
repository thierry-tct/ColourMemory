
/** cmCardFactory: provide the list of cards images
*/ 
function cmCardFactory() {
    var factory = {};
    var cards=[
        {'front':'Images/card_bg.gif', 'back':'Images/colour1.gif', 'enabled': true, showFace:[true,false]},
        {'front':'Images/card_bg.gif', 'back':'Images/colour2.gif', 'enabled': true, showFace:[true,false]},
        {'front':'Images/card_bg.gif', 'back':'Images/colour3.gif', 'enabled': true, showFace:[true,false]},
        {'front':'Images/card_bg.gif', 'back':'Images/colour4.gif', 'enabled': true, showFace:[true,false]},

        {'front':'Images/card_bg.gif', 'back':'Images/colour5.gif', 'enabled': true, showFace:[true,false]},
        {'front':'Images/card_bg.gif', 'back':'Images/colour6.gif', 'enabled': true, showFace:[true,false]},
        {'front':'Images/card_bg.gif', 'back':'Images/colour7.gif', 'enabled': true, showFace:[true,false]},
        {'front':'Images/card_bg.gif', 'back':'Images/colour8.gif', 'enabled': true, showFace:[true,false]},

        {'front':'Images/card_bg.gif', 'back':'Images/colour1.gif', 'enabled': true, showFace:[true,false]},
        {'front':'Images/card_bg.gif', 'back':'Images/colour2.gif', 'enabled': true, showFace:[true,false]},
        {'front':'Images/card_bg.gif', 'back':'Images/colour3.gif', 'enabled': true, showFace:[true,false]},
        {'front':'Images/card_bg.gif', 'back':'Images/colour4.gif', 'enabled': true, showFace:[true,false]},

        {'front':'Images/card_bg.gif', 'back':'Images/colour5.gif', 'enabled': true, showFace:[true,false]},
        {'front':'Images/card_bg.gif', 'back':'Images/colour6.gif', 'enabled': true, showFace:[true,false]},
        {'front':'Images/card_bg.gif', 'back':'Images/colour7.gif', 'enabled': true, showFace:[true,false]},
        {'front':'Images/card_bg.gif', 'back':'Images/colour8.gif', 'enabled': true, showFace:[true,false]}
    ];
    //var emptySlot = 'Images/empty_slot.png';

    factory.getCards = function(){
      
      var cardBuf = JSON.parse(JSON.stringify( cards ));
      return cardBuf;
    }
    return factory;
}

/**
  cmCardController: Main controller of the app,
  Provide most of the methods of control in the game
  */
function cmCardController($scope, $timeout, $interval, $http, cmCardFactory) {

  function init(){
     //Executed only when page is loaded
    $scope.currView = 'gameInstructions';

    //0 to 15 are the different cards, 16 is Start and Restart
    $scope.cursorOn = 16;   
    $scope.serverScores = {"myScore":"", "myRank":"","myGameRank":"" , "ranking":[]};
    $scope.startRestart = 'Start';

    //To select startRestart
    $scope.yIndex = 3;
    $scope.xIndex = 4;

    //set the number of best players in ranking
    $scope.topNum = 5;
  }

/**
  This method respond to the user selecton of start or restart
*/
  $scope.cmClickedRestart = function(){
    $interval.cancel($scope.timer);
    $scope.cards = cmCardFactory.getCards();
    $scope.yIndex = 0;
    $scope.xIndex = 0;
    $scope.boardSide = 4;   //this should not be modified anywhere else
    
    $scope.sound = "Sounds/move.wav";

    //Shuffle the cards
    $scope.cards.sort(function() { return 0.5 - Math.random() });
    $scope.score = 0;
    $scope.time = 0;
    $scope.name = "";
    $scope.email = "";

    $scope.cursorOn = 0;

    $scope.numPairsLeft = $scope.cards.length/2;

    $scope.numFlippedCards = 0;

    //index in the cards array of the previously opened card. -1 if none opened
    $scope.openedCard = -1;   
    $scope.timer = $interval(function () {
        $scope.time = $scope.time + 1;
      }, 1000);
  };

  /**
    This method respond to the user selection of cards
  */
  $scope.cmClickedCard = function(index){
    if($scope.numFlippedCards >= 2){
      return;
    }
    $scope.numFlippedCards++;

    function swapFrontBack(ind){
      $scope.cards[ind].showFace[0] =  !$scope.cards[ind].showFace[0];
      $scope.cards[ind].showFace[1] =  !$scope.cards[ind].showFace[1]
    }
    //Disable the card
    $scope.cards[index].enabled = false;
    $scope.sound = "Sounds/rien.wav";
    $timeout(function(){
      $scope.sound = "Sounds/flip_card.wav";
    },1);
    swapFrontBack(index);    
    if($scope.openedCard >= 0){
      if(($scope.cards[index].back).localeCompare($scope.cards[$scope.openedCard].back)){
        //Missmatch
        $scope.sub1 = true;
        $timeout(function(){
          $scope.sound = "Sounds/rien.wav";
          $timeout(function(){
            $scope.sound = "Sounds/bloc.wav";
          },1);
          swapFrontBack(index);
          swapFrontBack($scope.openedCard);
          $scope.score--;
          $scope.cards[index].enabled = false
          //Re-enable both cards
          $scope.cards[index].enabled = true;
          $scope.cards[$scope.openedCard].enabled = true;
          $scope.openedCard = -1;
          $scope.sub1 = false;
          $scope.numFlippedCards = 0;
        }, 300);
      }
      else{
        //Match
        $scope.add1 = true;
        $timeout(function(){
          $scope.cards[index].showFace[1] = false;
          $scope.cards[$scope.openedCard].showFace[1] = false;
          $scope.cards[index].showFace[0] = false;
          $scope.cards[$scope.openedCard].showFace[0] = false;
          $scope.score++;          
          $scope.openedCard = -1;
          $scope.numPairsLeft--;
          $scope.add1 = false;
          $scope.numFlippedCards = 0;
          $scope.sound = "Sounds/rien.wav";
          $timeout(function(){
            $scope.sound = "Sounds/valide.wav";
          },1);
          if($scope.numPairsLeft <= 0){
            $interval.cancel($scope.timer);
            $timeout(function(){
              
              //get data fields and submit or cancel
              $scope.currView = 'infoSubmit';
              $scope.cursorOn = 17;    //Name of InfoSubmit
               $timeout(function(){
                 $scope.typeName=true;
               },50);
              //reminder of processing done in the function keyboard($document)		
            }, 50);
          }
        }, 300);
      }
     
    }
    else{
      $scope.openedCard = index;
    }
  }
  
  /**
    This is the component that make the REST Request to the server to submit results 
    when a game end
  */
  $scope.ajaxPostRequest = function(){
    if($scope.name === ""){
      alert("Please input your name first then submit");
      return;
    }
    if($scope.email === ""){
      alert("Please input your Email first then submit");
      return;
    }
    var sentData = {
      'name':$scope.name, 
      'email':$scope.email,
      'score':$scope.score, 
      'time':$scope.time, 
      'topNum':$scope.topNum
    };
    var res = $http.post('/gamesave', sentData, {method: 'JSONP'});
    res.success(function(retData, status, headers, config) {
      $scope.serverScores = retData;
      $scope.currView = 'resultsView';
      $scope.cursorOn = 16; //Restart 
    });
    res.error(function(retData, status, headers, config) {
      alert( "Error Status: " + status + "\nfailure message: " + JSON.stringify({retData: retData}));
    });
  }
 
  $scope.selected = function(pos){
      if($scope.cursorOn === pos){
        return true;
      }
      return false;
    };

  $scope.viewWhat = function(viewType){
    if($scope.currView  === viewType){
      return true;
    }
    return false;
  };

  init();
}

//App definition (AngularJS module)
var colourMemoryApp = angular.module('colourMemoryApp', []);
colourMemoryApp.factory('cmCardFactory', cmCardFactory);
colourMemoryApp.controller('cmCardController', cmCardController);
colourMemoryApp.directive("cmkeyboard", keyboard);

/**
  Module in charge of event, managing keyboard input events 
  and interacting with the main controller to apply them into the app
  */
function keyboard($document) {

  return {
    link: function(scope, element, attrs) {

      $document.on("keydown", function(event) {
        scope.$apply(function() { 
          
          if(scope.cursorOn >= scope.boardSide * scope.boardSide){  //for start/restart
            scope.xIndex = scope.boardSide;
            scope.yIndex = scope.boardSide - 1;
          }
          else{ //for cards
            scope.xIndex = scope.cursorOn % scope.boardSide;
            scope.yIndex = (scope.cursorOn - scope.xIndex) / scope.boardSide;
          }

          // if left key
          if(event.which === 37){ 
            if(scope.viewWhat('cardsTable') && scope.numPairsLeft > 0){
                if(scope.xIndex === 0){
                  if(scope.yIndex === scope.boardSide - 1){
                     scope.xIndex = scope.boardSide;
                  }
                  else{
                    scope.xIndex = scope.boardSide - 1;
                  }
                }
                else{
                  scope.xIndex = scope.xIndex - 1;
                }

                //move cursor
                scope.cursorOn = scope.yIndex * scope.boardSide + scope.xIndex;
            }
            else{
              if(scope.viewWhat('infoSubmit')){
                switch(scope.cursorOn){
                  case 16:scope.cursorOn = 20;break;
                  case 17:break;
                  case 18:break;
                  case 19:scope.cursorOn = 16;break;
                  case 20:scope.cursorOn = 19;break;
                  default:scope.cursorOn = 18;break;
                }
              }
            }

            //Remove original functionalities
            if(!(scope.cursorOn === 17 || scope.cursorOn === 18)){   //not input text position
              event.stopPropagation();
              event.preventDefault();
            }
          }

          // if up key
          if(event.which === 38){ 
             if(scope.viewWhat('cardsTable') && scope.numPairsLeft > 0){
                if(scope.xIndex < scope.boardSide){
                  if(scope.yIndex === 0){
                    scope.yIndex = scope.boardSide - 1;
                  }
                  else{
                    scope.yIndex = scope.yIndex - 1;
                  }
                }

                //move cursor
                scope.cursorOn = scope.yIndex * scope.boardSide + scope.xIndex;
             }
             else{
              if(scope.viewWhat('infoSubmit')){
                switch(scope.cursorOn){
                  case 16:break;
                  case 17:scope.cursorOn = 19;break;
                  case 18:scope.cursorOn = 17;scope.typeEmail=false;scope.typeName=true;break;
                  case 19:scope.cursorOn = 18;scope.typeName=false;scope.typeEmail=true;break;
                  case 20:break;
                  default:scope.cursorOn = 18;break;
                }
              }
             }

            //Remove original functionalities
            event.stopPropagation();
            event.preventDefault();
          }

          // if right key
          if(event.which === 39){ 
             if(scope.viewWhat('cardsTable') && scope.numPairsLeft > 0){
                if(scope.yIndex === scope.boardSide - 1){
                  scope.xIndex = (scope.xIndex + 1) % (scope.boardSide + 1);
                }
                else{
                  scope.xIndex = (scope.xIndex + 1) % scope.boardSide;
                }

                //move cursor
                scope.cursorOn = scope.yIndex * scope.boardSide + scope.xIndex;
             }
             else{
              if(scope.viewWhat('infoSubmit')){
                switch(scope.cursorOn){
                  case 16:scope.cursorOn = 19;break;
                  case 17:break;
                  case 18:break;
                  case 19:scope.cursorOn = 20;break;
                  case 20:scope.cursorOn = 16;break;
                  default:scope.cursorOn = 17;break;
                }
              }
            }

            //Remove original functionalities
            if(!(scope.cursorOn === 17 || scope.cursorOn === 18)){   //not input text position
              event.stopPropagation();
              event.preventDefault();
            }
          }

          // if down key
          if(event.which === 40){ 
            if(scope.viewWhat('cardsTable') && scope.numPairsLeft > 0){
                if(scope.xIndex < scope.boardSide){
                  scope.yIndex = (scope.yIndex + 1) % scope.boardSide;
                }

                //move cursor
                scope.cursorOn = scope.yIndex * scope.boardSide + scope.xIndex;
            }
            else{
              if(scope.viewWhat('infoSubmit')){
                switch(scope.cursorOn){
                  case 16:break;
                  case 17:scope.cursorOn = 18;scope.typeName=false;scope.typeEmail=true;break;
                  case 18:scope.cursorOn = 19;break;
                  case 19:scope.cursorOn = 17;scope.typeEmail=false;scope.typeName=true;break;
                  case 20:break;
                  default:scope.cursorOn = 18;break;
                }
              }
            }

            //Remove original functionalities
            event.stopPropagation();
            event.preventDefault();
          }

          // if Enter
          if(event.which === 13){ 
            if(scope.viewWhat('cardsTable')){
              if(scope.xIndex === 4){  //selected restart
                scope.cmClickedRestart(); 
              }
              else{ //selected a card
                var cardIndex = scope.yIndex * scope.boardSide + scope.xIndex;
                if(scope.cards[cardIndex].enabled){
                  scope.cmClickedCard(cardIndex);
                }
              }
            }
            else{
              if(scope.viewWhat('gameInstructions') || scope.viewWhat('resultsView')){
                  scope.currView = 'cardsTable';
                  scope.startRestart = 'Restart';
                  scope.cmClickedRestart(); 
                }
                else{
                  if(scope.viewWhat('infoSubmit')){
                    switch(scope.cursorOn){
                      case 16:{
                        scope.currView = 'cardsTable';
                        scope.cmClickedRestart(); 
                        break;
                      }
                      case 17:break;
                      case 18:break;
                      case 19:scope.ajaxPostRequest();break;
                      case 20:{
                        scope.currView = 'cardsTable';
                        scope.cursorOn = 16;
                        break;
                      }
                      default:break;
                    }
                  }
                }
            }

            //Remove original functionalities
            event.stopPropagation();
            event.preventDefault();
          }   
        });
      });
    }
  }
}

//This directive helps to focus the input thext as the user moves the cursor
colourMemoryApp.directive('focusMe', function($timeout) {
  return {
    scope: { trigger: '@focusMe' },
    link: function(scope, element) {
      scope.$watch('trigger', function(value) {
        if(value === "true") { 
          $timeout(function() {
            element[0].focus(); 
          });
        }
      });
    }
  };
});